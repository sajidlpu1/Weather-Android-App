package android.com.intugine_v10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    TextView Banglore_temp, Banglore_min, Banglore_max, Banglore_humidity, Mumbai_temp, Mumbai_min, Mumbai_max, Mumbai_humidity, Delhi_temp, Delhi_min, Delhi_max, Delhi_humidity;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Banglore_temp = (TextView) findViewById(R.id.bang_temp);
        Banglore_min = (TextView) findViewById(R.id.bang_min);
        Banglore_max = (TextView) findViewById(R.id.bang_max);
        Banglore_humidity = (TextView) findViewById(R.id.bang_humi);

        Mumbai_temp = (TextView) findViewById(R.id.mumb_temp);
        Mumbai_min = (TextView) findViewById(R.id.mumb_min);
        Mumbai_max = (TextView) findViewById(R.id.mumb_max);
        Mumbai_humidity = (TextView) findViewById(R.id.mumb_humi);

        Delhi_temp = (TextView) findViewById(R.id.delhi_temp);
        Delhi_min = (TextView) findViewById(R.id.delhi_min);
        Delhi_max = (TextView) findViewById(R.id.delhi_max);
        Delhi_humidity = (TextView) findViewById(R.id.delhi_humi);



        Banglore_Weather_Today();
        Mumbai_Weather_Today();
        Delhi_Weather_Today();

    }

    public void Banglore_Weather_Today()
    {
        String burl = "https://openweathermap.org/data/2.5/weather?q=Bangalore, india&units=metric&appid=439d4b804bc8187953eb36d2a8c26a02";

        JsonObjectRequest banglore_jor = new JsonObjectRequest(Request.Method.GET, burl, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                    try {

                        JSONObject banglore_main = response.getJSONObject("main");

                        String btemp = String.valueOf(banglore_main.getInt("temp"));
                        String btemp_min = String.valueOf(banglore_main.getDouble("temp_min"));
                        String btemp_max = String.valueOf(banglore_main.getDouble("temp_max"));
                        String bhumidity = String.valueOf(banglore_main.getInt("humidity"));

                        Banglore_temp.setText(btemp);
                        Banglore_min.setText(btemp_min);
                        Banglore_max.setText(btemp_max);
                        Banglore_humidity.setText(bhumidity);

                    } catch (JSONException e){
                        e.printStackTrace();
                    }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });


        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(banglore_jor);
    }



    public void Mumbai_Weather_Today()
    {
        String murl = "https://openweathermap.org/data/2.5/weather?q=Mumbai, india&units=metric&appid=439d4b804bc8187953eb36d2a8c26a02";

        JsonObjectRequest mumbai_jor = new JsonObjectRequest(Request.Method.GET, murl, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {

                    JSONObject mumbai_main = response.getJSONObject("main");

                    String mtemp = String.valueOf(mumbai_main.getInt("temp"));
                    String mtemp_min = String.valueOf(mumbai_main.getDouble("temp_min"));
                    String mtemp_max = String.valueOf(mumbai_main.getDouble("temp_max"));
                    String mhumidity = String.valueOf(mumbai_main.getInt("humidity"));

                    Mumbai_temp.setText(mtemp);
                    Mumbai_min.setText(mtemp_min);
                    Mumbai_max.setText(mtemp_max);
                    Mumbai_humidity.setText(mhumidity);

                } catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });


        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(mumbai_jor);
    }



    public void Delhi_Weather_Today()
    {
        String durl = "https://openweathermap.org/data/2.5/weather?q=Delhi, india&units=metric&appid=439d4b804bc8187953eb36d2a8c26a02";

        JsonObjectRequest delhi_jor = new JsonObjectRequest(Request.Method.GET, durl, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {

                    JSONObject delhi_main = response.getJSONObject("main");

                    String dtemp = String.valueOf(delhi_main.getInt("temp"));
                    String dtemp_min = String.valueOf(delhi_main.getDouble("temp_min"));
                    String dtemp_max = String.valueOf(delhi_main.getDouble("temp_max"));
                    String dhumidity = String.valueOf(delhi_main.getInt("humidity"));

                    Delhi_temp.setText(dtemp);
                    Delhi_min.setText(dtemp_min);
                    Delhi_max.setText(dtemp_max);
                    Delhi_humidity.setText(dhumidity);

                } catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });


        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(delhi_jor);
    }


}
